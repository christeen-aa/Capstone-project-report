from flask import Flask,  render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "sqlite:///ToDo.db"
db = SQLAlchemy(app)

#model for displaying content of database
class ToDo(db.Model):

    id = db.Column(db.Integer, primary_key = True)
    content = db.Column(db.String(300),nullable = False)
    date_created = db.Column(db.DateTime, default = datetime.now())

    def __repr__(self):
        return "<Task %r>" % self.id

    
@app.route("/",methods = ["POST","GET"])
def index():
    #fetched the post request and the task content from the form
    if request.method == "POST":
        task_content = request.form["content"]
        new_task = ToDo(content = task_content)
#added the task to the db
        try:
           db.session.add(new_task)
           db.session.commit()
           return redirect("/")
        except Exception as e:
          return f"unable to add task: {e}" 

    else:
        tasks = ToDo.query.order_by(ToDo.date_created).all()
        return render_template("index.html",tasks = tasks)
        

@app.route("/delete/<int:id>")
def delete(id):
    delete_task = ToDo.query.get_or_404(id)

    try:
         db.session.delete(delete_task)
         db.session.commit()
         return redirect("/")
    
    except Exception as e:
        return f"could not delete the task {e}"
    
@app.route("/update/<int:id>",methods = ["POST","GET"])
def update(id):
    task = ToDo.query.get_or_404(id)
    if request.method == "POST":
        task.content = request.form["content"]

        try:
            db.session.commit()
            return redirect("/")
        except Exception as e:
            return f"failed to update task: {e}"
    else:
        return render_template("update.html",task=task)
   
        
if __name__ == "__main__": 
    with app.app_context():
        db.create_all()
    app.run(debug = True)
