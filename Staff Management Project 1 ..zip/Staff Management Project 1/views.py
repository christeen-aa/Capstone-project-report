from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import Employee, Department, Role
from datetime import datetime

# Homepage / index
def index(request):
    return render(request, "index.html")


# Show all employees
def all_emp(request):
    emps = Employee.objects.all()
    return render(request, "all_emp.html", {"emps": emps})


# Add an employee
def add_emp(request):
    if request.method == "POST":
        first_name = request.POST.get("first_name")
        last_name = request.POST.get("last_name")
        dept_id = request.POST.get("dept")
        role_id = request.POST.get("role")
        salary = int(request.POST.get("salary"))  # Convert to int
        bonus = int(request.POST.get("bonus") or 0)  # Convert to int
        phone = request.POST.get("phone")
        hire_date = request.POST.get("hire_date")  # Get hire date from request
        dept_obj = Department.objects.get(id=dept_id)
        role_obj = Role.objects.get(id=role_id)

        new_emp = Employee(
            first_name=first_name,
            last_name=last_name,
            dept=dept_obj,
            role=role_obj,
            salary=salary,
            bonus=bonus,
            phone=phone,
            hire_date=hire_date  # Use the date from the request
        )
        new_emp.save()
        return redirect("all_emp")
    
    depts = Department.objects.all()
    roles = Role.objects.all()
    return render(request, "add_emp.html", {"depts": depts, "roles": roles})


# Delete an employee
def del_emp(request, id):
    try:
        emp = Employee.objects.get(id=id)
        if request.method =="POST":
            emp.delete()
            return redirect("all_emp")
        return render(request,"del_emp.html",{"emp":emp})
    except Employee.DoesNotExist:
        return HttpResponse("Employee not found")


# Filter employees
def filter_emp(request):
    emps = Employee.objects.all()
    depts = Department.objects.all()
    roles = Role.objects.all()
    if request.method == "POST":
        name = request.POST.get("name")
        dept_id = request.POST.get("dept")
        role_id = request.POST.get("role")
        if name:
            emps = emps.filter(first_name__icontains=name) | emps.filter(last_name__icontains=name)
        if dept_id:
            emps = emps.filter(dept__id=dept_id)
        if role_id:
            emps = emps.filter(role__id=role_id)
    return render(request, "filter_emp.html", {"emps": emps, "depts": depts, "roles": roles})


